public interface GreetingService {
    public String sayHello(String name);
}

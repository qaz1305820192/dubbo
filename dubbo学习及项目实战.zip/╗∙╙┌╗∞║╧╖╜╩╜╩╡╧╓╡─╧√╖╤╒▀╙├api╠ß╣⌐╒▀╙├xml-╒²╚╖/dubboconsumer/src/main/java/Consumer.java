import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;

import java.io.IOException;

public class Consumer {
    public static void main(String[] args) throws IOException {
        ReferenceConfig<GreetingService> referenceConfig = new ReferenceConfig<GreetingService>();
        referenceConfig.setApplication(new ApplicationConfig("first-dubbo-consumer"));
        referenceConfig.setRegistry(new RegistryConfig("zookeeper://127.0.0.1:2181"));
        referenceConfig.setInterface(GreetingService.class);
        referenceConfig.setGroup("q1");//如果服务端设置了组名 这里千万要记得设置啊 ，不然找不到对应服务者
        GreetingService greetingService = referenceConfig.get();
        System.out.println(greetingService.sayHello("world"));
        System.in.read();
    }
}
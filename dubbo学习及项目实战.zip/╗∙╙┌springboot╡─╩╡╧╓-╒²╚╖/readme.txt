分别启动 消费者和服务者模块（ main（）函数）

然后访问：http://localhost:8081//initOrder?uid=1
返回json参数

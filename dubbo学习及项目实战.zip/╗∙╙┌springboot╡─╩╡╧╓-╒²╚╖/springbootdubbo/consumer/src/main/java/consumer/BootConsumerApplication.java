package consumer;

import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 *值得注意的是 springboot会自动扫描 该文件下及其目录的注解，
 * 如果conterller进不来，说明 要么路径写错，要么是没有扫描到包（也就是放错了位置）
 * */
@EnableDubbo //开启基于注解的dubbo功能
@SpringBootApplication
public class BootConsumerApplication {
    public static void main(String[] args){
        SpringApplication.run(BootConsumerApplication.class,args);
    }
}

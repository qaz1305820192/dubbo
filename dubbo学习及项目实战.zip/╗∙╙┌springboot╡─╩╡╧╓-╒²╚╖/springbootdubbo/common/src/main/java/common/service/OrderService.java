package common.service;

import common.pojo.UserAddress;

import java.util.List;

public interface OrderService {
    /**
     * 初始化订单
     * @param userID
     * @return
     */
    public List<UserAddress> initOrder(String userID);
}
